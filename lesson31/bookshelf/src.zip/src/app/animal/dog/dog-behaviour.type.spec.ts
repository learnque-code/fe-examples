import { DogsBehaviours } from './dog-behaviour.type';

describe('DogBehaviour', () => {
  it('should create an instance', () => {
    expect(new DogsBehaviours()).toBeTruthy();
  });
});
