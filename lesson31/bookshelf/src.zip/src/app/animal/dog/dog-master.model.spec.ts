import { DogMaster } from './dog-master.model';

describe('DogMaster', () => {
  it('should create an instance', () => {
    expect(new DogMaster()).toBeTruthy();
  });
});
