export type DogsBehaviours = { [key: string]: string };
