export class DogMaster {
  public firstName: string = "";
  public lastName: string = "";
}
