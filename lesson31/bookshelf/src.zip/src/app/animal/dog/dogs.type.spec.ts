import { Dogs } from './dogs.type';

describe('Dogs', () => {
  it('should create an instance', () => {
    expect(new Dogs()).toBeTruthy();
  });
});
