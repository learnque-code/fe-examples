import {Dog} from "./dog.model";

export type Dogs = Dog[];
