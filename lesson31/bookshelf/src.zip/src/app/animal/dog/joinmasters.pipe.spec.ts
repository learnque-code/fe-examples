import { JoinmastersPipe } from './joinmasters.pipe';

describe('JoinmastersPipe', () => {
  it('create an instance', () => {
    const pipe = new JoinmastersPipe();
    expect(pipe).toBeTruthy();
  });
});
