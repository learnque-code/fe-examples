import { JoinauthorsPipe } from './joinauthors.pipe';

describe('JoinauthorsPipe', () => {
  it('create an instance', () => {
    const pipe = new JoinauthorsPipe();
    expect(pipe).toBeTruthy();
  });
});
