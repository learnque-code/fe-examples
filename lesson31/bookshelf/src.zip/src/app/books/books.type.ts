import {Book} from "./book/book.model";

export type Books = Book[];
