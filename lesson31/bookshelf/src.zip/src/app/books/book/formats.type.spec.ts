import { Formats } from './formats.type';

describe('Formats', () => {
  it('should create an instance', () => {
    expect(new Formats()).toBeTruthy();
  });
});
