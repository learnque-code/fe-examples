export class Author {
  birth_year: number | null = null;
  death_year: number | null = null;
  name: string = "";
}
