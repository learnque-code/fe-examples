export type Languages = string[];
