export type Formats = { [key: string]: string };
