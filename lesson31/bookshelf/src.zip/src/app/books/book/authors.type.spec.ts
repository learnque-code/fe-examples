import { Authors } from './authors.type';

describe('Authors', () => {
  it('should create an instance', () => {
    expect(new Authors()).toBeTruthy();
  });
});
