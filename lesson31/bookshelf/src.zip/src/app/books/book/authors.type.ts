import {Author} from "./author.model";

export type Authors = Author[];
