import { Languages } from './languages.type';

describe('Languages', () => {
  it('should create an instance', () => {
    expect(new Languages()).toBeTruthy();
  });
});
