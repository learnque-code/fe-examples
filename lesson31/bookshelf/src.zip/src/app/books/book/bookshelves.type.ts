export type Bookshelves = string[];

