export type Subjects = string[];
